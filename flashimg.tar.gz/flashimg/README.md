flashimg
========

Flashimg is a tool used to create and handle flash image file. Usefull for QEMU.

[git://gitorious.org/flashimg/flashimg.git](git://gitorious.org/flashimg/flashimg.git)
