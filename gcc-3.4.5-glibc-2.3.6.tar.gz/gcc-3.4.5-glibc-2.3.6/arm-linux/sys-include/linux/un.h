#if defined(__GNUC__) && !defined(__STRICT_ANSI__)
#warning "You should include <sys/un.h>. This time I will do it for you."
#endif
#include <sys/un.h>

