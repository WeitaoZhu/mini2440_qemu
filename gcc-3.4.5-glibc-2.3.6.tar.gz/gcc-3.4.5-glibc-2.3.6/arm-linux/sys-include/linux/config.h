#error "Compilation aborted. Please read the FAQ for linux-libc-headers package."
#error "(can be found at http://ep09.pld-linux.org/~mmazur/linux-libc-headers/doc/)"

